import express from "express"; import mongoose from "mongoose"; import dotenv from "dotenv"; import Book from "./models/Book.js";
dotenv.config(); const app=express(),PORT=process.env.PORT||3003; app.use(express.json());
const err=(res,status,message,details=null)=>res.status(status).json({success:false,status,message,details});
const valid=id=>mongoose.Types.ObjectId.isValid(id);
function failed(res,e){if(["ValidationError","CastError"].includes(e.name))return err(res,400,"Book validation failed.",Object.values(e.errors||{}).map(x=>x.message));console.error(e);return err(res,500,"An unexpected server error occurred.");}
app.get("/",(q,s)=>s.json({success:true,message:"Book API is running"}));
app.get("/books",async(q,s)=>{try{const f={};if(q.query.category)f.category={$regex:String(q.query.category),$options:"i"};if(q.query.author)f.author={$regex:String(q.query.author),$options:"i"};const a=await Book.find(f).sort({title:1});s.json({success:true,count:a.length,data:a});}catch(e){failed(s,e);}});
app.get("/books/:id",async(q,s)=>{if(!valid(q.params.id))return err(s,400,"Invalid book ID.");try{const x=await Book.findById(q.params.id);if(!x)return err(s,404,"Book not found.");s.json({success:true,data:x});}catch(e){failed(s,e);}});
app.post("/books",async(q,s)=>{
 const {title,author,category,publicationYear,availableCopies}=q.body||{},p=[],year=Number(publicationYear),copies=Number(availableCopies);
 if(typeof title!=="string"||!title.trim())p.push("title must not be empty.");
 if(typeof author!=="string"||!author.trim())p.push("author must not be empty.");
 if(typeof category!=="string"||!category.trim())p.push("category must not be empty.");
 if(!Number.isInteger(year)||year<1450||year>new Date().getFullYear())p.push("publicationYear must be a valid year.");
 if(!Number.isInteger(copies)||copies<0)p.push("availableCopies must be a non-negative integer.");
 if(p.length)return err(s,400,"Book validation failed.",p);
 try{const x=await Book.create({title:title.trim(),author:author.trim(),category:category.trim(),publicationYear:year,availableCopies:copies});s.status(201).json({success:true,message:"Book created successfully.",data:x});}catch(e){failed(s,e);}
});
app.use((q,s)=>err(s,404,"Route not found."));
if(!process.env.MONGO_URI){console.error("Copy .env.example to .env and configure MONGO_URI.");process.exit(1);}
mongoose.connect(process.env.MONGO_URI).then(()=>app.listen(PORT,()=>console.log(`Book API: http://localhost:${PORT}`))).catch(e=>{console.error("MongoDB connection failed:",e.message);process.exit(1);});
