import mongoose from "mongoose";
const schema=new mongoose.Schema({
 title:{type:String,required:true,trim:true},author:{type:String,required:true,trim:true},
 category:{type:String,required:true,trim:true},
 publicationYear:{type:Number,required:true,min:1450,max:new Date().getFullYear()},
 availableCopies:{type:Number,required:true,min:0,validate:Number.isInteger}
},{timestamps:true});
export default mongoose.model("Book",schema);
