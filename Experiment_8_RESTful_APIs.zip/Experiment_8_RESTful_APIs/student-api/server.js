import express from "express";
const app=express(), PORT=process.env.PORT||3001;
app.use(express.json());
let students=[
{id:1,name:"Aarav Shah",department:"Computer Engineering",semester:5},
{id:2,name:"Diya Patel",department:"Information Technology",semester:5},
{id:3,name:"Kabir Mehta",department:"Electronics",semester:5},
{id:4,name:"Anaya Rao",department:"Computer Engineering",semester:5},
{id:5,name:"Vivaan Desai",department:"Artificial Intelligence",semester:5}
];
const err=(res,status,message,details=null)=>res.status(status).json({success:false,status,message,details});
app.get("/",(req,res)=>res.json({success:true,message:"Student API is running"}));
app.get("/students",(req,res)=>res.status(200).json({success:true,count:students.length,data:students}));
app.get("/students/:id",(req,res)=>{
 const id=Number(req.params.id), s=students.find(x=>x.id===id);
 if(!Number.isInteger(id)||id<1)return err(res,400,"Student ID must be a positive integer.");
 if(!s)return err(res,404,`Student with id ${id} was not found.`);
 res.json({success:true,data:s});
});
app.post("/students",(req,res)=>{
 const {name,department,semester}=req.body||{}, problems=[];
 if(typeof name!=="string"||!name.trim())problems.push("name is required.");
 if(typeof department!=="string"||!department.trim())problems.push("department is required.");
 if(!Number.isInteger(Number(semester))||Number(semester)<1)problems.push("semester must be a positive integer.");
 if(problems.length)return err(res,400,"Student validation failed.",problems);
 const s={id:Math.max(0,...students.map(x=>x.id))+1,name:name.trim(),department:department.trim(),semester:Number(semester)};
 students.push(s); res.status(201).json({success:true,message:"Student created successfully.",data:s});
});
app.use((req,res)=>err(res,404,"Route not found."));
app.listen(PORT,()=>console.log(`Student API: http://localhost:${PORT}`));
