import express from "express"; import mongoose from "mongoose"; import dotenv from "dotenv"; import Course from "./models/Course.js";
dotenv.config(); const app=express(),PORT=process.env.PORT||3002; app.use(express.json());
const err=(res,status,message,details=null)=>res.status(status).json({success:false,status,message,details});
const valid=id=>mongoose.Types.ObjectId.isValid(id);
function failed(res,e){if(["ValidationError","CastError"].includes(e.name)||e.code===11000)return err(res,400,"Course validation failed.",e.code===11000?["courseCode must be unique."]:Object.values(e.errors||{}).map(x=>x.message));console.error(e);return err(res,500,"An unexpected server error occurred.");}
app.get("/",(q,s)=>s.json({success:true,message:"Course API is running"}));
app.post("/courses",async(q,s)=>{try{const x=await Course.create(q.body);s.status(201).json({success:true,message:"Course created successfully.",data:x});}catch(e){failed(s,e);}});
app.get("/courses",async(q,s)=>{try{const a=await Course.find().sort({courseCode:1});s.json({success:true,count:a.length,data:a});}catch(e){failed(s,e);}});
app.get("/courses/:id",async(q,s)=>{if(!valid(q.params.id))return err(s,400,"Invalid course ID.");try{const x=await Course.findById(q.params.id);if(!x)return err(s,404,"Course not found.");s.json({success:true,data:x});}catch(e){failed(s,e);}});
app.put("/courses/:id",async(q,s)=>{if(!valid(q.params.id))return err(s,400,"Invalid course ID.");try{const x=await Course.findByIdAndUpdate(q.params.id,q.body,{new:true,runValidators:true});if(!x)return err(s,404,"Course not found.");s.json({success:true,message:"Course updated successfully.",data:x});}catch(e){failed(s,e);}});
app.delete("/courses/:id",async(q,s)=>{if(!valid(q.params.id))return err(s,400,"Invalid course ID.");try{const x=await Course.findByIdAndDelete(q.params.id);if(!x)return err(s,404,"Course not found.");s.json({success:true,message:"Course deleted successfully.",data:x});}catch(e){failed(s,e);}});
app.use((q,s)=>err(s,404,"Route not found."));
if(!process.env.MONGO_URI){console.error("Copy .env.example to .env and configure MONGO_URI.");process.exit(1);}
mongoose.connect(process.env.MONGO_URI).then(()=>app.listen(PORT,()=>console.log(`Course API: http://localhost:${PORT}`))).catch(e=>{console.error("MongoDB connection failed:",e.message);process.exit(1);});
