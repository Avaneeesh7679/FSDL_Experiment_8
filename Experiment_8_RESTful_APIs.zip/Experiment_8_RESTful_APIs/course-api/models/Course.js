import mongoose from "mongoose";
const schema=new mongoose.Schema({
 courseCode:{type:String,required:true,trim:true,unique:true},
 courseName:{type:String,required:true,trim:true},
 department:{type:String,required:true,trim:true},
 credits:{type:Number,required:true,min:1,max:10},
 semester:{type:Number,required:true,min:1,max:8}
},{timestamps:true});
export default mongoose.model("Course",schema);
