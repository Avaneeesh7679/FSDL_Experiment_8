# Experiment 8 — RESTful APIs using Node.js and Express

This package implements the three tasks in the supplied reference PDF:
1. Student API with an in-memory array.
2. Course API with MongoDB/Mongoose and full CRUD.
3. Book catalogue API with MongoDB/Mongoose, filters and validation.

## Requirements
- Node.js LTS and npm
- MongoDB running locally or a MongoDB Atlas URI
- Postman

## Run Task 1
```bash
cd student-api
npm install
npm start
```
Base URL: http://localhost:3001
- GET /students
- GET /students/3
- GET /students/99 (404 example)
- POST /students with JSON: `{"name":"Ishaan Kulkarni","department":"Computer Engineering","semester":5}`
- POST /students with missing fields (400 example)

Student data is in memory and resets when the server restarts.

## Run Task 2
Start MongoDB. In `course-api`, create `.env` from `.env.example`:
```bash
cp .env.example .env
```
Default local settings:
```env
PORT=3002
MONGO_URI=mongodb://127.0.0.1:27017/wpl_experiment8
```
Then run:
```bash
npm install
npm start
```
Endpoints: POST /courses, GET /courses, GET /courses/:id, PUT /courses/:id, DELETE /courses/:id.
Example POST JSON:
`{"courseCode":"CS501","courseName":"Web Programming","department":"Computer Engineering","credits":4,"semester":5}`

## Run Task 3
In `book-api`, create `.env` from `.env.example`, confirm MongoDB URI, then:
```bash
npm install
npm start
```
Base URL: http://localhost:3003
- POST /books
- GET /books
- GET /books?category=Science
- GET /books?author=Cormen
- GET /books/:id

Example POST JSON:
`{"title":"Introduction to Algorithms","author":"Cormen","category":"Science","publicationYear":2022,"availableCopies":5}`

## Postman
Import `postman/WPL_Experiment_8.postman_collection.json`. Start the matching server before sending requests. For course/book routes using an ID, copy the `_id` from the successful POST response and replace `REPLACE_WITH_ID` in the request URL.

## Important
No database credentials, node_modules or fabricated test screenshots are included. Configure each `.env` locally. Run the APIs and capture your own Postman screenshots; enter the actual observed responses in your practical record.
