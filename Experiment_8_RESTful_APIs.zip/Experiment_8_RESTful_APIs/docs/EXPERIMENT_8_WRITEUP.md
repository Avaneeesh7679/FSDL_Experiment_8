# Experiment 8 — Designing and Implementing RESTful APIs using Node.js and Express

## Aim and Objectives
1. To understand REST architectural principles and the role of HTTP methods in web application development.
2. To develop REST API endpoints using Node.js and Express.
3. To implement CRUD operations and connect an API to a database.
4. To use HTTP status codes, request parameters, validation and error handling.
5. To test REST API endpoints using Postman.

## CO to be achieved
CO3: Develop modular, component-based front-end applications using modern JavaScript libraries and frameworks.

## Apparatus / Software tools used
1. Node.js and npm.
2. Express.js.
3. MongoDB.
4. Mongoose.
5. dotenv.
6. Visual Studio Code.
7. Postman.
8. MongoDB Compass or MongoDB Atlas.

## Problem Statement
Develop and test RESTful APIs for student, course and book records. Task 1 uses an in-memory student array. Task 2 uses MongoDB/Mongoose for course CRUD. Task 3 uses MongoDB/Mongoose for a book catalogue with query filtering and validation.

## HTML tags used
No HTML tags were used. The experiment is server-side and the APIs exchange JSON data, tested through Postman.

## Code / Folder structure
The package contains three separate projects: `student-api`, `course-api`, and `book-api`. Course and book projects include Mongoose models and `.env.example` files. A Postman collection is included in the `postman` folder.

## Stepwise Procedure / Algorithm
1. Check Node.js and npm using `node -v` and `npm -v`.
2. Install/start MongoDB locally or prepare a MongoDB Atlas connection.
3. Create three folders: student-api, course-api and book-api.
4. Install Express in student-api and configure `express.json()`.
5. Create at least five student objects in an array.
6. Implement GET /students, GET /students/:id and POST /students.
7. Test valid retrieval, missing ID, valid creation and missing-field validation in Postman.
8. In course-api, configure `MONGO_URI` in `.env` and connect using Mongoose.
9. Create the Course schema with courseCode, courseName, department, credits and semester.
10. Implement POST, GET all, GET by ID, PUT and DELETE course routes using async/await and try/catch.
11. In book-api, configure MongoDB and create the Book schema with title, author, category, publicationYear and availableCopies.
12. Implement POST /books, GET /books, GET /books/:id and category/author query filters.
13. Validate title, author, publication year and available copies.
14. Return suitable status codes and consistent JSON error responses.
15. Import the Postman collection and test all endpoints on ports 3001, 3002 and 3003.
16. Record the actual status codes and responses, and capture screenshots.

## Output / Observation

### Task 1 — Student API (http://localhost:3001)
| Endpoint | Method | Test | Expected status |
|---|---|---|---|
| /students | GET | Retrieve all students | 200 OK |
| /students/3 | GET | Retrieve student ID 3 | 200 OK |
| /students/99 | GET | Unknown ID | 404 Not Found |
| /students | POST | Valid student JSON | 201 Created |
| /students | POST | Missing required fields | 400 Bad Request |

### Task 2 — Course API (http://localhost:3002)
| Endpoint | Method | Test | Expected status |
|---|---|---|---|
| /courses | POST | Create valid course | 201 Created |
| /courses | GET | Retrieve all courses | 200 OK |
| /courses/:id | GET | Retrieve existing course | 200 OK |
| /courses/:id | PUT | Update course | 200 OK |
| /courses/:id | DELETE | Delete course | 200 OK |
| /courses/:id | GET | Retrieve deleted/missing course | 404 Not Found |

### Task 3 — Book API (http://localhost:3003)
| Endpoint | Method | Test | Expected status |
|---|---|---|---|
| /books | POST | Create valid book | 201 Created |
| /books | POST | Invalid fields | 400 Bad Request |
| /books | GET | Retrieve all books | 200 OK |
| /books?category=Science | GET | Filter by category | 200 OK |
| /books?author=Cormen | GET | Filter by author | 200 OK |
| /books/:id | GET | Missing book | 404 Not Found |

These are expected observations from the supplied implementation. Confirm them by running the services and recording actual Postman responses.

## Link of Generated APIs
- Student API: http://localhost:3001/students
- Course API: http://localhost:3002/courses
- Book API: http://localhost:3003/books

These are local URLs and work only while the relevant server is running.

## Post-lab Questions

### 1. What is a RESTful API? Explain resources and endpoints.
A RESTful API allows a client and server to communicate using HTTP requests. Data is treated as resources, such as students, courses or books. An endpoint is the URL used to access a resource. For example, GET /courses retrieves courses and POST /courses creates a course.

### 2. Differentiate between GET, POST, PUT, PATCH and DELETE.
- GET retrieves data.
- POST creates a new resource.
- PUT updates or replaces a resource.
- PATCH updates selected fields.
- DELETE removes a resource.

### 3. Differentiate req.params, req.query and req.body.
- `req.params` reads values in the route path, such as the ID in `/students/3`.
- `req.query` reads URL query values, such as `category=Science`.
- `req.body` reads data sent in a POST or PUT request body.

### 4. Why are HTTP status codes important? Explain 200, 201, 400, 404 and 500.
Status codes tell the client the result of a request. 200 means success, 201 means a resource was created, 400 means invalid input, 404 means the requested route or record was not found, and 500 means an unexpected server error occurred.

### 5. What is the purpose of express.json()?
It parses JSON request bodies and makes the parsed data available through `req.body`. It is used before routes that accept JSON input.

### 6. Why is a Mongoose schema useful?
A schema defines document fields, data types and validation rules. It helps maintain consistent data and prevents invalid records from being saved.

### 7. How should an API handle invalid input and database errors safely?
Validate incoming data and return 400 for invalid input. Use try/catch for database operations and return a general 500 response for unexpected failures. Do not expose credentials or internal stack traces.

### 8. What is the difference between an in-memory array and a database?
An in-memory array stores data in the running process and loses it when the server restarts. A database stores data persistently, so records remain after restarting the server.

## Conclusion
Through this experiment, I learned how RESTful APIs are developed using Node.js and Express. I created endpoints for student records and understood how HTTP methods, route parameters and JSON request bodies are used to manage data. I connected MongoDB with Mongoose to perform CRUD operations on course records. I also developed a book catalogue API with query-based filtering and input validation. Testing the endpoints through Postman helped me understand status codes and error handling. Overall, the experiment strengthened my understanding of backend development and database integration.
