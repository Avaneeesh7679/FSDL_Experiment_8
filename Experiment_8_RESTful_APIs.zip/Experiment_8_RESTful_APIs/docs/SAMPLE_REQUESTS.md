# Sample JSON request bodies

POST /students:
```json
{"name":"Ishaan Kulkarni","department":"Computer Engineering","semester":5}
```

POST /courses:
```json
{"courseCode":"CS501","courseName":"Web Programming","department":"Computer Engineering","credits":4,"semester":5}
```

POST /books:
```json
{"title":"Introduction to Algorithms","author":"Cormen","category":"Science","publicationYear":2022,"availableCopies":5}
```

Invalid POST /books example:
```json
{"title":"","author":"","category":"Science","publicationYear":2098,"availableCopies":-3}
```
